/* 
 * File:   Blink.cpp
 * Author: williamvolkweis
 * 
 * Created on September 5, 2015, 9:37 PM
 */

#include "Blink.h"


Blink::Blink() {
}

Blink::Blink(const Blink& orig) {
}

Blink::~Blink() {
}


